package com.game.game.DWP;

public class DWPRoom {
    int id_dwp;
    int archi_type;
    String area_type;
    int id_room;


    public DWPRoom(int id_dwp, int archi_type, String area_type, int id_room) {
        this.id_dwp = id_dwp;
        this.archi_type = archi_type;
        this.area_type = area_type;
        this.id_room = id_room;
    }

    public int getId_dwp() {
        return id_dwp;
    }

    public void setId_dwp(int id_dwp) {
        this.id_dwp = id_dwp;
    }

    public int getArchi_type() {
        return archi_type;
    }

    public void setArchi_type(int archi_type) {
        this.archi_type = archi_type;
    }

    public String getArea_type() {
        return area_type;
    }

    public void setArea_type(String area_type) {
        this.area_type = area_type;
    }

    public int getId_room() {
        return id_room;
    }

    public void setId_room(int id_room) {
        this.id_room = id_room;
    }
}
