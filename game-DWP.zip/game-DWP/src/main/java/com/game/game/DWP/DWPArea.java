package com.game.game.DWP;

public class DWPArea {
    int archi_type=1;
    int biT1_1;
    int biT2_1;
    int os_1;
    int sr_1;
    int biT1_2;
    int biT2_2;
    int os_2;
    int sr_2;

    public DWPArea(){

    }

    public int getArchi_type() {
        return archi_type;
    }

    public void setArchi_type(int archi_type) {
        this.archi_type = archi_type;
    }

    public int getBiT1_1() {
        return biT1_1;
    }

    public void setBiT1_1(int biT1_1) {
        this.biT1_1 = biT1_1;
    }

    public int getBiT2_1() {
        return biT2_1;
    }

    public void setBiT2_1(int biT2_1) {
        this.biT2_1 = biT2_1;
    }

    public int getOs_1() {
        return os_1;
    }

    public void setOs_1(int os_1) {
        this.os_1 = os_1;
    }

    public int getSr_1() {
        return sr_1;
    }

    public void setSr_1(int sr_1) {
        this.sr_1 = sr_1;
    }

    public int getBiT1_2() {
        return biT1_2;
    }

    public void setBiT1_2(int biT1_2) {
        this.biT1_2 = biT1_2;
    }

    public int getBiT2_2() {
        return biT2_2;
    }

    public void setBiT2_2(int biT2_2) {
        this.biT2_2 = biT2_2;
    }

    public int getOs_2() {
        return os_2;
    }

    public void setOs_2(int os_2) {
        this.os_2 = os_2;
    }

    public int getSr_2() {
        return sr_2;
    }

    public void setSr_2(int sr_2) {
        this.sr_2 = sr_2;
    }

    @Override
    public String toString() {
        return "DWPArea{" +
                "biT1_1=" + biT1_1 +
                ", biT2_1=" + biT2_1 +
                ", os_1=" + os_1 +
                ", sr_1=" + sr_1 +
                ", biT1_2=" + biT1_2 +
                ", biT2_2=" + biT2_2 +
                ", os_2=" + os_2 +
                ", sr_2=" + sr_2 +
                '}';
    }
}
