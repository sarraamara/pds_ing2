package com.game.game.DWP.services;

import com.game.game.DWP.DWPArea;
import com.game.game.DWP.DWPRoom;
import com.game.game.DWP.Room;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class DWPMapService {


    private List<Room> listRoom= new ArrayList<Room>();
    private List<DWPRoom> listDWPRoom= new ArrayList<DWPRoom>();
    private boolean configured=false;
    private boolean reconfigure=false;

    public void addRoom(Room room){
        listRoom.add(room);
    }
    public Room getRoom(int id_room){
        for(Room r: listRoom)
        {
            if(r.getId_room() == id_room){
                return r;
            }
        }
        return null;
    }

    public void deleteRoom(int id_room){
        for(Room r: listRoom)
        {
            if(r.getId_room() == id_room){
                listRoom.remove(r);
                break;
            }
        }
    }
    public void addDWPRoom(DWPRoom dwpRoom){
        listDWPRoom.add(dwpRoom);
    }

    public List<DWPRoom> getAllDWPRoom(){
        return listDWPRoom;
    }

    public List<Room> getRoomsByArea(String area_type){
        List<Room> roomByAreaList = new ArrayList<>();
        for(DWPRoom dr: listDWPRoom){
            if(dr.getArea_type()==area_type){
                roomByAreaList.add(getRoom(dr.getId_room()));
            }
        }
        return roomByAreaList;
    }
    public void configureMap(DWPArea dwparea){

        if(!configured) {
            int id = listRoom.size();

            for (int i = 0; i < dwparea.getBiT1_1(); i++) {
                id++;
                this.addRoom(new Room(id, "BI", 1, 5));
                this.addDWPRoom(new DWPRoom(1, dwparea.getArchi_type(), "AO1", id));
            }

            for (int i = 0; i < dwparea.getBiT2_1(); i++) {
                id++;
                this.addRoom(new Room(id, "BI", 2, 5));
                this.addDWPRoom(new DWPRoom(1, dwparea.getArchi_type(), "AO1", id));
            }

            for (int i = 0; i < dwparea.getOs_1(); i++) {
                id++;
                this.addRoom(new Room(id, "OS", 5, 5));
                this.addDWPRoom(new DWPRoom(1, dwparea.getArchi_type(), "AO1", id));
            }

            for (int i = 0; i < dwparea.getSr_1(); i++) {
                id++;
                this.addRoom(new Room(id, "SR", 3, 5));
                this.addDWPRoom(new DWPRoom(1, dwparea.getArchi_type(), "AO1", id));
            }

            for (int i = 0; i < dwparea.getBiT1_2(); i++) {
                id++;
                this.addRoom(new Room(id, "BI", 1, 5));
                this.addDWPRoom(new DWPRoom(1, dwparea.getArchi_type(), "AO2", id));
            }

            for (int i = 0; i < dwparea.getBiT2_2(); i++) {
                id++;
                this.addRoom(new Room(id, "BI", 2, 5));
                this.addDWPRoom(new DWPRoom(1, dwparea.getArchi_type(), "AO2", id));
            }

            for (int i = 0; i < dwparea.getOs_2(); i++) {
                id++;
                this.addRoom(new Room(id, "OS", 5, 5));
                this.addDWPRoom(new DWPRoom(1, dwparea.getArchi_type(), "AO2", id));
            }

            for (int i = 0; i < dwparea.getSr_2(); i++) {
                id++;
                this.addRoom(new Room(id, "SR", 3, 5));
                this.addDWPRoom(new DWPRoom(1, dwparea.getArchi_type(), "AO2", id));
            }
            configured=true;
        }
    }

    public void deleteAllRoomsByIdDWP(int id_dwp) {
        for(DWPRoom dwpr: listDWPRoom){
            if(dwpr.getId_dwp()==id_dwp){
                this.deleteRoom(dwpr.getId_room());
                listDWPRoom.remove(dwpr);
            }
        }
    }
    public boolean isConfigured() {
        return configured;
    }

    public void setConfigured(boolean configured) {
        this.configured = configured;
    }

    public boolean isReconfigure() {
        return reconfigure;
    }

    public void setReconfigure(boolean reconfigure) {
        this.reconfigure = reconfigure;
    }


}
